""""""
######################################
""" DO NOT CHANGE THIS FILE PLEASE """
######################################
""""""

from os.path import isfile, join, splitext, getsize, basename, exists
from os import listdir, walk, system, popen, rename, mkdir, remove
from shutil import copyfile
import subprocess
import tarfile
import zipfile
import ffmpy
import glob
import time
import sys
import re

CHECKED = \
"""
                           /
                        //  
                      //    
                   ///      
                 ///.       
               ////         
             *///           
  *         ////            
   //     ////*             
    .////////               
      //////                
        ///                 
"""

QUESTIONS_PATH = 'questions'
TASKS_PATH = 'tasks'
OUTPUT_PATH = '_output'

def compress(crf, scale):
  questions = [(join(QUESTIONS_PATH, f), "questions") for f in listdir(QUESTIONS_PATH) if isfile(join(QUESTIONS_PATH, f))]
  tasks = [(join(TASKS_PATH, f), "tasks") for f in listdir(TASKS_PATH) if isfile(join(TASKS_PATH, f))]
  files = tasks+questions
  print("\033[94m-.-.-.-.-.-.-.-.-.-.-.-.-.\x1b[0m")
  for file_tupple in files:
    file, root = file_tupple
    ff = ffmpy.FFprobe(
      inputs={file: '-hide_banner -loglevel panic -show_streams'}
    )
    stdout, stderr = ff.run(stdout=subprocess.PIPE)
    if stderr: raise Exception(stderr)
    ftype=re.search(r"codec_type=(\w+)", stdout.decode("utf-8"))
    if ftype:
      ftype=ftype.group(1)
      if not ftype: raise Exception("Something went wrong to find filetype in compressing!")
      # Audio
      if ftype == "audio":
        print("Passing '{}' from compression.".format(basename(file)))
        copyfile(file, "{}/{}/{}".format(OUTPUT_PATH, root, basename(file)))
      # Video
      elif ftype == "video":
        if getsize(file) < 10*1024*1024:
          print("Passing '{}' from compression.".format(basename(file)))
          copyfile(file, "{}/{}/{}".format(OUTPUT_PATH, root, basename(file)))
          continue
        ff = ffmpy.FFprobe(
          inputs={file: '-v error -of flat=s=_ -select_streams v:0 -show_entries stream=height,width'}
        )
        stdout, stderr = ff.run(stdout=subprocess.PIPE)
        if stderr: raise Exception(stderr)
        dim=re.findall(r"streams_stream_0_\w+=(\d+)", stdout.decode("utf-8"))
        width = int(dim[0])
        height = int(dim[1])
        crf = 18 if not crf else crf
        scale = 2 if not scale else scale
        ffargs = '-hide_banner -loglevel error -stats -c:a mp3 -ab 128 -vcodec libx265 -x265-params log-level=error -crf {}'.format(crf)
        if (width>=1280 and height>=720) and (getsize(file) >= 15*1024*1024):
          ffargs += " -vf scale=iw/{}:ih/{}".format(scale, scale)
          print("Compressing '{}' with crf={} and scale={}:".format(basename(file), crf, scale))
        else:
          print("Compressing '{}' with crf={}:".format(basename(file), crf))
        ff = ffmpy.FFmpeg (
          inputs={file: None},
          outputs={"{}/{}/{}.mp4".format(OUTPUT_PATH, root, splitext(basename(file))[0]): ffargs}
        )
        ff.run()
      # Every Other Filetypes
      else:
        raise Exception("An Unknown File Was Found: " + file)
    print("\033[94m-.-.-.-.-.-.-.-.-.-.-.-.-.\x1b[0m")

def tardir(path, tarh):
  for root, dirs, files in walk(path):
    for file in files:
      if root==OUTPUT_PATH:
        tarh.add(file)
      else:
        tarh.add(join(root, file))

def splitter(file, chunk):
  name, _ = splitext(file)
  name, _ = splitext(name)
  with open(file, 'rb') as infile:
    for n, raw_bytes in enumerate(iter(lambda: infile.read(chunk), b'')):
      with open('{}.part{}'.format(name, n+1), 'wb') as outfile:
        outfile.write(raw_bytes)

def main():
  # get args
  args = sys.argv
  stname = args[1]
  stid = args[2]
  crf = args[3] if len(args)>3 else None
  scale = args[4] if len(args)>4 else None

  # create/recreate relevant directories
  pathlist = ["{}/{}".format(OUTPUT_PATH, QUESTIONS_PATH), "{}/{}".format(OUTPUT_PATH, TASKS_PATH)]
  for path in pathlist:
    if not exists(path):
      mkdir(path)
    else:
      files = glob.glob(path+"/*")
      for f in files: remove(f)

  # compress media
  compress(crf, scale)

  # final compression 
  zipname = "{}_{}.zip".format(stname, stid)
  tarname = splitext(zipname)[0] + ".tar.xz"
  with tarfile.open(tarname, "w:xz") as tarf:
    tardir(OUTPUT_PATH, tarf)

  # split the compressed file into parts
  chunk = 5*1024*1024
  splitter(tarname, chunk)

start = 0
end = 0
try:
  start = time.time()
  main()
  print('\033[92m' + ">>> Compressed Successfully" + '\x1b[0m')
  print(CHECKED)
  print("")
except Exception as err:
  print('\033[91m' + str(err) + '\x1b[0m')
finally:
  end = time.time()
  print("\033[1m" + "Elapsed time: " + str((end-start)/60) + " minutes" + "\x1b[0m")
  print("\033[94m-.-.-.-.-.-.-.-.-.-.-.-.-.\x1b[0m")
