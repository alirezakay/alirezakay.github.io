/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

/* This file is designed for use with ISim build 0x7708f090 */

#define XSI_HIDE_SYMBOL_SPEC true
#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif
static const char *ng0 = "E:/ProgrDocs/ToTheProgrammer/Main/University/Term4/Computer Architecture/myCPUv3/VHDLs/ControlMemory.vhd";
extern char *IEEE_P_3620187407;

int ieee_p_3620187407_sub_514432868_3965413181(char *, char *, char *);


static void work_a_0292008527_0831356973_p_0(char *t0)
{
    char *t1;
    char *t2;
    unsigned char t3;
    unsigned char t4;
    char *t5;
    char *t6;
    char *t7;
    unsigned char t8;
    unsigned int t9;
    char *t10;
    char *t11;
    int t12;
    unsigned int t13;
    unsigned int t14;
    char *t15;
    char *t16;
    int t18;
    unsigned int t19;
    unsigned int t20;
    char *t21;
    char *t22;
    int t24;
    unsigned int t25;
    unsigned int t26;
    char *t27;
    char *t28;
    int t30;
    unsigned int t31;
    unsigned int t32;
    char *t33;
    char *t34;
    int t36;
    unsigned int t37;
    unsigned int t38;
    char *t39;
    char *t40;
    int t42;
    unsigned int t43;
    unsigned int t44;
    char *t45;
    char *t46;
    int t48;
    unsigned int t49;
    unsigned int t50;
    char *t51;
    char *t52;
    int t54;
    unsigned int t55;
    unsigned int t56;
    char *t57;
    char *t58;
    int t60;
    unsigned int t61;
    unsigned int t62;
    char *t63;
    char *t64;
    int t66;
    unsigned int t67;
    unsigned int t68;
    char *t69;
    char *t70;
    int t72;
    unsigned int t73;
    unsigned int t74;
    char *t75;
    char *t76;
    int t78;
    unsigned int t79;
    unsigned int t80;
    char *t81;
    char *t82;
    int t84;
    unsigned int t85;
    unsigned int t86;
    char *t87;
    char *t88;
    char *t89;
    char *t90;
    char *t91;
    char *t92;

LAB0:    xsi_set_current_line(48, ng0);
    t1 = (t0 + 1192U);
    t2 = *((char **)t1);
    t3 = *((unsigned char *)t2);
    t4 = (t3 == (unsigned char)2);
    if (t4 != 0)
        goto LAB2;

LAB4:    xsi_set_current_line(67, ng0);
    t1 = (t0 + 1352U);
    t2 = *((char **)t1);
    t1 = (t0 + 6624U);
    t12 = ieee_p_3620187407_sub_514432868_3965413181(IEEE_P_3620187407, t2, t1);
    t5 = (t0 + 2208U);
    t6 = *((char **)t5);
    t5 = (t6 + 0);
    *((int *)t5) = t12;
    xsi_set_current_line(69, ng0);
    t1 = (t0 + 1672U);
    t2 = *((char **)t1);
    t1 = (t0 + 2208U);
    t5 = *((char **)t1);
    t12 = *((int *)t5);
    t18 = (t12 - 0);
    t9 = (t18 * 1);
    xsi_vhdl_check_range_of_index(0, 15, 1, t12);
    t13 = (19U * t9);
    t14 = (0 + t13);
    t1 = (t2 + t14);
    t6 = (t0 + 3656);
    t7 = (t6 + 56U);
    t10 = *((char **)t7);
    t11 = (t10 + 56U);
    t15 = *((char **)t11);
    memcpy(t15, t1, 19U);
    xsi_driver_first_trans_fast_port(t6);

LAB3:    t1 = (t0 + 3512);
    *((int *)t1) = 1;

LAB1:    return;
LAB2:    xsi_set_current_line(49, ng0);
    t1 = xsi_get_transient_memory(304U);
    memset(t1, 0, 304U);
    t5 = t1;
    t6 = (t0 + 7036);
    t8 = (19U != 0);
    if (t8 == 1)
        goto LAB5;

LAB6:    t10 = (t0 + 7055);
    t12 = (0 - 0);
    t13 = (t12 * 1);
    t14 = (19U * t13);
    t15 = (t5 + t14);
    memcpy(t15, t10, 19U);
    t16 = (t0 + 7074);
    t18 = (1 - 0);
    t19 = (t18 * 1);
    t20 = (19U * t19);
    t21 = (t5 + t20);
    memcpy(t21, t16, 19U);
    t22 = (t0 + 7093);
    t24 = (2 - 0);
    t25 = (t24 * 1);
    t26 = (19U * t25);
    t27 = (t5 + t26);
    memcpy(t27, t22, 19U);
    t28 = (t0 + 7112);
    t30 = (3 - 0);
    t31 = (t30 * 1);
    t32 = (19U * t31);
    t33 = (t5 + t32);
    memcpy(t33, t28, 19U);
    t34 = (t0 + 7131);
    t36 = (4 - 0);
    t37 = (t36 * 1);
    t38 = (19U * t37);
    t39 = (t5 + t38);
    memcpy(t39, t34, 19U);
    t40 = (t0 + 7150);
    t42 = (5 - 0);
    t43 = (t42 * 1);
    t44 = (19U * t43);
    t45 = (t5 + t44);
    memcpy(t45, t40, 19U);
    t46 = (t0 + 7169);
    t48 = (6 - 0);
    t49 = (t48 * 1);
    t50 = (19U * t49);
    t51 = (t5 + t50);
    memcpy(t51, t46, 19U);
    t52 = (t0 + 7188);
    t54 = (7 - 0);
    t55 = (t54 * 1);
    t56 = (19U * t55);
    t57 = (t5 + t56);
    memcpy(t57, t52, 19U);
    t58 = (t0 + 7207);
    t60 = (8 - 0);
    t61 = (t60 * 1);
    t62 = (19U * t61);
    t63 = (t5 + t62);
    memcpy(t63, t58, 19U);
    t64 = (t0 + 7226);
    t66 = (9 - 0);
    t67 = (t66 * 1);
    t68 = (19U * t67);
    t69 = (t5 + t68);
    memcpy(t69, t64, 19U);
    t70 = (t0 + 7245);
    t72 = (10 - 0);
    t73 = (t72 * 1);
    t74 = (19U * t73);
    t75 = (t5 + t74);
    memcpy(t75, t70, 19U);
    t76 = (t0 + 7264);
    t78 = (11 - 0);
    t79 = (t78 * 1);
    t80 = (19U * t79);
    t81 = (t5 + t80);
    memcpy(t81, t76, 19U);
    t82 = (t0 + 7283);
    t84 = (12 - 0);
    t85 = (t84 * 1);
    t86 = (19U * t85);
    t87 = (t5 + t86);
    memcpy(t87, t82, 19U);
    t88 = (t0 + 3592);
    t89 = (t88 + 56U);
    t90 = *((char **)t89);
    t91 = (t90 + 56U);
    t92 = *((char **)t91);
    memcpy(t92, t1, 304U);
    xsi_driver_first_trans_fast(t88);
    xsi_set_current_line(64, ng0);
    t1 = (t0 + 7302);
    t5 = (t0 + 3656);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    t10 = (t7 + 56U);
    t11 = *((char **)t10);
    memcpy(t11, t1, 19U);
    xsi_driver_first_trans_fast_port(t5);
    goto LAB3;

LAB5:    t9 = (304U / 19U);
    xsi_mem_set_data(t5, t6, 19U, t9);
    goto LAB6;

}


void ieee_p_2592010699_sub_3130575329_503743352();

extern void work_a_0292008527_0831356973_init()
{
	static char *pe[] = {(void *)work_a_0292008527_0831356973_p_0};
	xsi_register_didat("work_a_0292008527_0831356973", "isim/tb1_isim_beh.exe.sim/work/a_0292008527_0831356973.didat");
	xsi_register_executes(pe);
	xsi_register_resolution_function(1, 2, (void *)ieee_p_2592010699_sub_3130575329_503743352, 5);
}
