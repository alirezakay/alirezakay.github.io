/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

/* This file is designed for use with ISim build 0x7708f090 */

#define XSI_HIDE_SYMBOL_SPEC true
#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif
static const char *ng0 = "E:/ProgrDocs/ToTheProgrammer/Main/University/Term4/Computer Architecture/myCPUv3/VHDLs/alu.vhd";
extern char *IEEE_P_2592010699;
extern char *IEEE_P_3620187407;

char *ieee_p_2592010699_sub_1735675855_503743352(char *, char *, char *, char *, char *, char *);
char *ieee_p_2592010699_sub_795620321_503743352(char *, char *, char *, char *, char *, char *);
unsigned char ieee_p_3620187407_sub_1742983514_3965413181(char *, char *, char *, char *, char *);
unsigned char ieee_p_3620187407_sub_2546382208_3965413181(char *, char *, char *, int );
unsigned char ieee_p_3620187407_sub_2546418145_3965413181(char *, char *, char *, int );
char *ieee_p_3620187407_sub_767668596_3965413181(char *, char *, char *, char *, char *, char *);
char *ieee_p_3620187407_sub_767740470_3965413181(char *, char *, char *, char *, char *, char *);


static void work_a_1459262711_1516540902_p_0(char *t0)
{
    char t25[16];
    char t31[16];
    char t32[16];
    char t33[16];
    char t35[16];
    char t36[16];
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    int t5;
    char *t6;
    int t7;
    char *t8;
    char *t9;
    int t10;
    char *t11;
    char *t12;
    int t13;
    char *t14;
    char *t15;
    int t16;
    char *t17;
    char *t18;
    int t19;
    char *t20;
    char *t21;
    int t22;
    char *t23;
    char *t24;
    char *t26;
    char *t27;
    char *t28;
    char *t29;
    unsigned int t30;
    unsigned char t34;
    unsigned int t37;
    unsigned int t38;
    unsigned char t39;
    unsigned char t40;
    unsigned char t41;
    unsigned char t42;
    unsigned char t43;
    unsigned char t44;
    unsigned char t45;
    unsigned char t46;
    char *t47;
    unsigned char t48;
    char *t49;
    char *t50;
    char *t51;
    char *t52;
    char *t53;
    char *t54;
    unsigned char t55;
    char *t56;
    char *t57;
    char *t58;
    char *t59;
    char *t60;

LAB0:    xsi_set_current_line(30, ng0);
    t1 = (t0 + 7976);
    t3 = (t0 + 2848U);
    t4 = *((char **)t3);
    t3 = (t4 + 0);
    memcpy(t3, t1, 9U);
    xsi_set_current_line(31, ng0);
    t1 = (t0 + 7985);
    t3 = (t0 + 3088U);
    t4 = *((char **)t3);
    t3 = (t4 + 0);
    memcpy(t3, t1, 8U);
    xsi_set_current_line(32, ng0);
    t1 = (t0 + 1512U);
    t2 = *((char **)t1);
    t1 = (t0 + 2968U);
    t3 = *((char **)t1);
    t1 = (t3 + 0);
    memcpy(t1, t2, 3U);
    xsi_set_current_line(34, ng0);
    t1 = (t0 + 2968U);
    t2 = *((char **)t1);
    t1 = (t0 + 7993);
    t5 = xsi_mem_cmp(t1, t2, 3U);
    if (t5 == 1)
        goto LAB3;

LAB11:    t4 = (t0 + 7996);
    t7 = xsi_mem_cmp(t4, t2, 3U);
    if (t7 == 1)
        goto LAB4;

LAB12:    t8 = (t0 + 7999);
    t10 = xsi_mem_cmp(t8, t2, 3U);
    if (t10 == 1)
        goto LAB5;

LAB13:    t11 = (t0 + 8002);
    t13 = xsi_mem_cmp(t11, t2, 3U);
    if (t13 == 1)
        goto LAB6;

LAB14:    t14 = (t0 + 8005);
    t16 = xsi_mem_cmp(t14, t2, 3U);
    if (t16 == 1)
        goto LAB7;

LAB15:    t17 = (t0 + 8008);
    t19 = xsi_mem_cmp(t17, t2, 3U);
    if (t19 == 1)
        goto LAB8;

LAB16:    t20 = (t0 + 8011);
    t22 = xsi_mem_cmp(t20, t2, 3U);
    if (t22 == 1)
        goto LAB9;

LAB17:
LAB10:    xsi_set_current_line(47, ng0);

LAB2:    xsi_set_current_line(51, ng0);
    t1 = (t0 + 2848U);
    t2 = *((char **)t1);
    t1 = (t0 + 7872U);
    t34 = ieee_p_3620187407_sub_2546382208_3965413181(IEEE_P_3620187407, t2, t1, 0);
    if (t34 != 0)
        goto LAB22;

LAB24:    xsi_set_current_line(54, ng0);
    t1 = (t0 + 4472);
    t2 = (t1 + 56U);
    t3 = *((char **)t2);
    t4 = (t3 + 56U);
    t6 = *((char **)t4);
    *((unsigned char *)t6) = (unsigned char)2;
    xsi_driver_first_trans_fast_port(t1);

LAB23:    xsi_set_current_line(58, ng0);
    t1 = (t0 + 2848U);
    t2 = *((char **)t1);
    t1 = (t0 + 7872U);
    t34 = ieee_p_3620187407_sub_2546418145_3965413181(IEEE_P_3620187407, t2, t1, 0);
    if (t34 != 0)
        goto LAB25;

LAB27:    xsi_set_current_line(61, ng0);
    t1 = (t0 + 4536);
    t2 = (t1 + 56U);
    t3 = *((char **)t2);
    t4 = (t3 + 56U);
    t6 = *((char **)t4);
    *((unsigned char *)t6) = (unsigned char)2;
    xsi_driver_first_trans_fast_port(t1);

LAB26:    xsi_set_current_line(65, ng0);
    t1 = (t0 + 1032U);
    t2 = *((char **)t1);
    t1 = (t0 + 7808U);
    t3 = (t0 + 3088U);
    t4 = *((char **)t3);
    t3 = (t0 + 7904U);
    t41 = ieee_std_logic_unsigned_greater_stdv_stdv(IEEE_P_3620187407, t2, t1, t4, t3);
    if (t41 == 1)
        goto LAB37;

LAB38:    t40 = (unsigned char)0;

LAB39:    if (t40 == 1)
        goto LAB34;

LAB35:    t39 = (unsigned char)0;

LAB36:    if (t39 == 1)
        goto LAB31;

LAB32:    t21 = (t0 + 1032U);
    t23 = *((char **)t21);
    t21 = (t0 + 7808U);
    t24 = (t0 + 3088U);
    t26 = *((char **)t24);
    t24 = (t0 + 7904U);
    t46 = ieee_p_3620187407_sub_1742983514_3965413181(IEEE_P_3620187407, t23, t21, t26, t24);
    if (t46 == 1)
        goto LAB43;

LAB44:    t45 = (unsigned char)0;

LAB45:    if (t45 == 1)
        goto LAB40;

LAB41:    t44 = (unsigned char)0;

LAB42:    t34 = t44;

LAB33:    if (t34 != 0)
        goto LAB28;

LAB30:    xsi_set_current_line(69, ng0);
    t1 = (t0 + 4600);
    t2 = (t1 + 56U);
    t3 = *((char **)t2);
    t4 = (t3 + 56U);
    t6 = *((char **)t4);
    *((unsigned char *)t6) = (unsigned char)2;
    xsi_driver_first_trans_fast_port(t1);

LAB29:    xsi_set_current_line(73, ng0);
    t1 = (t0 + 2848U);
    t2 = *((char **)t1);
    t5 = (8 - 8);
    t30 = (t5 * -1);
    t37 = (1U * t30);
    t38 = (0 + t37);
    t1 = (t2 + t38);
    t34 = *((unsigned char *)t1);
    t39 = (t34 == (unsigned char)3);
    if (t39 != 0)
        goto LAB46;

LAB48:    xsi_set_current_line(76, ng0);
    t1 = (t0 + 4664);
    t2 = (t1 + 56U);
    t3 = *((char **)t2);
    t4 = (t3 + 56U);
    t6 = *((char **)t4);
    *((unsigned char *)t6) = (unsigned char)2;
    xsi_driver_first_trans_fast_port(t1);

LAB47:    xsi_set_current_line(80, ng0);
    t1 = (t0 + 2848U);
    t2 = *((char **)t1);
    t30 = (8 - 7);
    t37 = (t30 * 1U);
    t38 = (0 + t37);
    t1 = (t2 + t38);
    t3 = (t0 + 4728);
    t4 = (t3 + 56U);
    t6 = *((char **)t4);
    t8 = (t6 + 56U);
    t9 = *((char **)t8);
    memcpy(t9, t1, 8U);
    xsi_driver_first_trans_fast_port(t3);
    t1 = (t0 + 4392);
    *((int *)t1) = 1;

LAB1:    return;
LAB3:    xsi_set_current_line(35, ng0);
    t23 = (t0 + 1192U);
    t24 = *((char **)t23);
    t26 = ((IEEE_P_2592010699) + 4024);
    t27 = (t0 + 7824U);
    t23 = xsi_base_array_concat(t23, t25, t26, (char)99, (unsigned char)2, (char)97, t24, t27, (char)101);
    t28 = (t0 + 2848U);
    t29 = *((char **)t28);
    t28 = (t29 + 0);
    t30 = (1U + 8U);
    memcpy(t28, t23, t30);
    goto LAB2;

LAB4:    xsi_set_current_line(36, ng0);
    t1 = (t0 + 1032U);
    t2 = *((char **)t1);
    t3 = ((IEEE_P_2592010699) + 4024);
    t4 = (t0 + 7808U);
    t1 = xsi_base_array_concat(t1, t32, t3, (char)99, (unsigned char)2, (char)97, t2, t4, (char)101);
    t6 = (t0 + 1192U);
    t8 = *((char **)t6);
    t9 = ((IEEE_P_2592010699) + 4024);
    t11 = (t0 + 7824U);
    t6 = xsi_base_array_concat(t6, t33, t9, (char)99, (unsigned char)2, (char)97, t8, t11, (char)101);
    t12 = ieee_p_3620187407_sub_767668596_3965413181(IEEE_P_3620187407, t31, t1, t32, t6, t33);
    t14 = (t0 + 8014);
    t17 = (t0 + 1352U);
    t18 = *((char **)t17);
    t34 = *((unsigned char *)t18);
    t20 = ((IEEE_P_2592010699) + 4024);
    t21 = (t36 + 0U);
    t23 = (t21 + 0U);
    *((int *)t23) = 0;
    t23 = (t21 + 4U);
    *((int *)t23) = 7;
    t23 = (t21 + 8U);
    *((int *)t23) = 1;
    t5 = (7 - 0);
    t30 = (t5 * 1);
    t30 = (t30 + 1);
    t23 = (t21 + 12U);
    *((unsigned int *)t23) = t30;
    t17 = xsi_base_array_concat(t17, t35, t20, (char)97, t14, t36, (char)99, t34, (char)101);
    t23 = ieee_p_3620187407_sub_767668596_3965413181(IEEE_P_3620187407, t25, t12, t31, t17, t35);
    t24 = (t0 + 2848U);
    t26 = *((char **)t24);
    t24 = (t26 + 0);
    t27 = (t25 + 12U);
    t30 = *((unsigned int *)t27);
    t37 = (1U * t30);
    memcpy(t24, t23, t37);
    goto LAB2;

LAB5:    xsi_set_current_line(37, ng0);
    t1 = (t0 + 1032U);
    t2 = *((char **)t1);
    t3 = ((IEEE_P_2592010699) + 4024);
    t4 = (t0 + 7808U);
    t1 = xsi_base_array_concat(t1, t31, t3, (char)99, (unsigned char)2, (char)97, t2, t4, (char)101);
    t6 = (t0 + 1192U);
    t8 = *((char **)t6);
    t9 = ((IEEE_P_2592010699) + 4024);
    t11 = (t0 + 7824U);
    t6 = xsi_base_array_concat(t6, t32, t9, (char)99, (unsigned char)2, (char)97, t8, t11, (char)101);
    t12 = ieee_p_3620187407_sub_767668596_3965413181(IEEE_P_3620187407, t25, t1, t31, t6, t32);
    t14 = (t0 + 2848U);
    t15 = *((char **)t14);
    t14 = (t15 + 0);
    t17 = (t25 + 12U);
    t30 = *((unsigned int *)t17);
    t37 = (1U * t30);
    memcpy(t14, t12, t37);
    goto LAB2;

LAB6:    xsi_set_current_line(38, ng0);
    t1 = (t0 + 1032U);
    t2 = *((char **)t1);
    t1 = (t0 + 7808U);
    t3 = (t0 + 1192U);
    t4 = *((char **)t3);
    t3 = (t0 + 7824U);
    t6 = ieee_p_3620187407_sub_767740470_3965413181(IEEE_P_3620187407, t25, t2, t1, t4, t3);
    t9 = ((IEEE_P_2592010699) + 4024);
    t8 = xsi_base_array_concat(t8, t31, t9, (char)99, (unsigned char)2, (char)97, t6, t25, (char)101);
    t11 = (t0 + 2848U);
    t12 = *((char **)t11);
    t11 = (t12 + 0);
    t14 = (t25 + 12U);
    t30 = *((unsigned int *)t14);
    t37 = (1U * t30);
    t38 = (1U + t37);
    memcpy(t11, t8, t38);
    goto LAB2;

LAB7:    xsi_set_current_line(39, ng0);
    t1 = (t0 + 1032U);
    t2 = *((char **)t1);
    t1 = (t0 + 7808U);
    t3 = (t0 + 1192U);
    t4 = *((char **)t3);
    t3 = (t0 + 7824U);
    t6 = ieee_p_2592010699_sub_795620321_503743352(IEEE_P_2592010699, t25, t2, t1, t4, t3);
    t9 = ((IEEE_P_2592010699) + 4024);
    t8 = xsi_base_array_concat(t8, t31, t9, (char)99, (unsigned char)2, (char)97, t6, t25, (char)101);
    t11 = (t0 + 2848U);
    t12 = *((char **)t11);
    t11 = (t12 + 0);
    t14 = (t25 + 12U);
    t30 = *((unsigned int *)t14);
    t37 = (1U * t30);
    t38 = (1U + t37);
    memcpy(t11, t8, t38);
    goto LAB2;

LAB8:    xsi_set_current_line(40, ng0);
    t1 = (t0 + 1032U);
    t2 = *((char **)t1);
    t1 = (t0 + 7808U);
    t3 = (t0 + 1192U);
    t4 = *((char **)t3);
    t3 = (t0 + 7824U);
    t6 = ieee_p_2592010699_sub_1735675855_503743352(IEEE_P_2592010699, t25, t2, t1, t4, t3);
    t9 = ((IEEE_P_2592010699) + 4024);
    t8 = xsi_base_array_concat(t8, t31, t9, (char)99, (unsigned char)2, (char)97, t6, t25, (char)101);
    t11 = (t0 + 2848U);
    t12 = *((char **)t11);
    t11 = (t12 + 0);
    t14 = (t25 + 12U);
    t30 = *((unsigned int *)t14);
    t37 = (1U * t30);
    t38 = (1U + t37);
    memcpy(t11, t8, t38);
    goto LAB2;

LAB9:    xsi_set_current_line(42, ng0);
    t1 = (t0 + 1032U);
    t2 = *((char **)t1);
    t1 = (t0 + 7808U);
    t3 = (t0 + 1192U);
    t4 = *((char **)t3);
    t3 = (t0 + 7824U);
    t34 = ieee_p_3620187407_sub_1742983514_3965413181(IEEE_P_3620187407, t2, t1, t4, t3);
    if (t34 != 0)
        goto LAB19;

LAB21:    xsi_set_current_line(45, ng0);
    t1 = (t0 + 2848U);
    t2 = *((char **)t1);
    t1 = (t0 + 2848U);
    t3 = *((char **)t1);
    t1 = (t3 + 0);
    memcpy(t1, t2, 9U);

LAB20:    goto LAB2;

LAB18:;
LAB19:    xsi_set_current_line(43, ng0);
    t6 = (t0 + 8022);
    t9 = (t0 + 2848U);
    t11 = *((char **)t9);
    t9 = (t11 + 0);
    memcpy(t9, t6, 9U);
    goto LAB20;

LAB22:    xsi_set_current_line(52, ng0);
    t3 = (t0 + 4472);
    t4 = (t3 + 56U);
    t6 = *((char **)t4);
    t8 = (t6 + 56U);
    t9 = *((char **)t8);
    *((unsigned char *)t9) = (unsigned char)3;
    xsi_driver_first_trans_fast_port(t3);
    goto LAB23;

LAB25:    xsi_set_current_line(59, ng0);
    t3 = (t0 + 4536);
    t4 = (t3 + 56U);
    t6 = *((char **)t4);
    t8 = (t6 + 56U);
    t9 = *((char **)t8);
    *((unsigned char *)t9) = (unsigned char)3;
    xsi_driver_first_trans_fast_port(t3);
    goto LAB26;

LAB28:    xsi_set_current_line(67, ng0);
    t56 = (t0 + 4600);
    t57 = (t56 + 56U);
    t58 = *((char **)t57);
    t59 = (t58 + 56U);
    t60 = *((char **)t59);
    *((unsigned char *)t60) = (unsigned char)3;
    xsi_driver_first_trans_fast_port(t56);
    goto LAB29;

LAB31:    t34 = (unsigned char)1;
    goto LAB33;

LAB34:    t12 = (t0 + 2848U);
    t14 = *((char **)t12);
    t12 = (t0 + 7872U);
    t15 = (t0 + 3088U);
    t17 = *((char **)t15);
    t18 = ((IEEE_P_2592010699) + 4024);
    t20 = (t0 + 7904U);
    t15 = xsi_base_array_concat(t15, t25, t18, (char)99, (unsigned char)2, (char)97, t17, t20, (char)101);
    t43 = ieee_p_3620187407_sub_1742983514_3965413181(IEEE_P_3620187407, t14, t12, t15, t25);
    t39 = t43;
    goto LAB36;

LAB37:    t6 = (t0 + 1192U);
    t8 = *((char **)t6);
    t6 = (t0 + 7824U);
    t9 = (t0 + 3088U);
    t11 = *((char **)t9);
    t9 = (t0 + 7904U);
    t42 = ieee_std_logic_unsigned_greater_stdv_stdv(IEEE_P_3620187407, t8, t6, t11, t9);
    t40 = t42;
    goto LAB39;

LAB40:    t49 = (t0 + 2848U);
    t50 = *((char **)t49);
    t49 = (t0 + 7872U);
    t51 = (t0 + 3088U);
    t52 = *((char **)t51);
    t53 = ((IEEE_P_2592010699) + 4024);
    t54 = (t0 + 7904U);
    t51 = xsi_base_array_concat(t51, t31, t53, (char)99, (unsigned char)2, (char)97, t52, t54, (char)101);
    t55 = ieee_std_logic_unsigned_greater_stdv_stdv(IEEE_P_3620187407, t50, t49, t51, t31);
    t44 = t55;
    goto LAB42;

LAB43:    t27 = (t0 + 1192U);
    t28 = *((char **)t27);
    t27 = (t0 + 7824U);
    t29 = (t0 + 3088U);
    t47 = *((char **)t29);
    t29 = (t0 + 7904U);
    t48 = ieee_p_3620187407_sub_1742983514_3965413181(IEEE_P_3620187407, t28, t27, t47, t29);
    t45 = t48;
    goto LAB45;

LAB46:    xsi_set_current_line(74, ng0);
    t3 = (t0 + 4664);
    t4 = (t3 + 56U);
    t6 = *((char **)t4);
    t8 = (t6 + 56U);
    t9 = *((char **)t8);
    *((unsigned char *)t9) = (unsigned char)3;
    xsi_driver_first_trans_fast_port(t3);
    goto LAB47;

}


extern void work_a_1459262711_1516540902_init()
{
	static char *pe[] = {(void *)work_a_1459262711_1516540902_p_0};
	xsi_register_didat("work_a_1459262711_1516540902", "isim/tb1_isim_beh.exe.sim/work/a_1459262711_1516540902.didat");
	xsi_register_executes(pe);
}
