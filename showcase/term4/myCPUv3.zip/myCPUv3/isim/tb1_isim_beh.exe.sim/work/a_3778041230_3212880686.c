/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

/* This file is designed for use with ISim build 0x7708f090 */

#define XSI_HIDE_SYMBOL_SPEC true
#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif
static const char *ng0 = "E:/ProgrDocs/ToTheProgrammer/Main/University/Term4/Computer Architecture/myCPUv3/VHDLs/ROM1.vhd";



static void work_a_3778041230_3212880686_p_0(char *t0)
{
    char *t1;
    char *t2;
    unsigned int t3;
    unsigned int t4;
    unsigned int t5;
    char *t6;
    char *t7;
    char *t8;
    char *t9;
    char *t10;
    char *t11;

LAB0:    xsi_set_current_line(43, ng0);

LAB3:    t1 = (t0 + 1032U);
    t2 = *((char **)t1);
    t3 = (3 - 3);
    t4 = (t3 * 1U);
    t5 = (0 + t4);
    t1 = (t2 + t5);
    t6 = (t0 + 3176);
    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    t9 = (t8 + 56U);
    t10 = *((char **)t9);
    memcpy(t10, t1, 2U);
    xsi_driver_first_trans_fast(t6);

LAB2:    t11 = (t0 + 3080);
    *((int *)t11) = 1;

LAB1:    return;
LAB4:    goto LAB2;

}

static void work_a_3778041230_3212880686_p_1(char *t0)
{
    char *t1;
    char *t2;
    char *t3;
    int t4;
    char *t5;
    char *t6;
    unsigned int t7;
    unsigned int t8;
    unsigned int t9;
    char *t10;
    char *t11;
    int t12;
    char *t13;
    char *t14;
    int t15;
    char *t16;
    char *t17;
    int t18;
    char *t19;
    char *t20;
    int t21;
    char *t22;
    char *t23;
    char *t24;
    char *t25;
    char *t26;
    char *t27;
    char *t28;
    int t29;
    char *t30;

LAB0:    xsi_set_current_line(46, ng0);
    t1 = (t0 + 1352U);
    t2 = *((char **)t1);
    t1 = (t0 + 5334);
    t4 = xsi_mem_cmp(t1, t2, 2U);
    if (t4 == 1)
        goto LAB3;

LAB5:
LAB4:    xsi_set_current_line(56, ng0);
    t1 = (t0 + 1032U);
    t2 = *((char **)t1);
    t7 = (3 - 3);
    t8 = (t7 * 1U);
    t9 = (0 + t8);
    t1 = (t2 + t9);
    t3 = (t0 + 5372);
    t4 = xsi_mem_cmp(t3, t1, 3U);
    if (t4 == 1)
        goto LAB19;

LAB26:    t6 = (t0 + 5375);
    t12 = xsi_mem_cmp(t6, t1, 3U);
    if (t12 == 1)
        goto LAB20;

LAB27:    t11 = (t0 + 5378);
    t15 = xsi_mem_cmp(t11, t1, 3U);
    if (t15 == 1)
        goto LAB21;

LAB28:    t14 = (t0 + 5381);
    t18 = xsi_mem_cmp(t14, t1, 3U);
    if (t18 == 1)
        goto LAB22;

LAB29:    t17 = (t0 + 5384);
    t21 = xsi_mem_cmp(t17, t1, 3U);
    if (t21 == 1)
        goto LAB23;

LAB30:    t20 = (t0 + 5387);
    t29 = xsi_mem_cmp(t20, t1, 3U);
    if (t29 == 1)
        goto LAB24;

LAB31:
LAB25:    xsi_set_current_line(63, ng0);
    t1 = (t0 + 5414);
    t3 = (t0 + 3240);
    t5 = (t3 + 56U);
    t6 = *((char **)t5);
    t10 = (t6 + 56U);
    t11 = *((char **)t10);
    memcpy(t11, t1, 4U);
    xsi_driver_first_trans_fast_port(t3);

LAB18:
LAB2:    t1 = (t0 + 3096);
    *((int *)t1) = 1;

LAB1:    return;
LAB3:    xsi_set_current_line(48, ng0);
    t5 = (t0 + 1032U);
    t6 = *((char **)t5);
    t7 = (3 - 3);
    t8 = (t7 * 1U);
    t9 = (0 + t8);
    t5 = (t6 + t9);
    t10 = (t0 + 5336);
    t12 = xsi_mem_cmp(t10, t5, 4U);
    if (t12 == 1)
        goto LAB8;

LAB13:    t13 = (t0 + 5340);
    t15 = xsi_mem_cmp(t13, t5, 4U);
    if (t15 == 1)
        goto LAB9;

LAB14:    t16 = (t0 + 5344);
    t18 = xsi_mem_cmp(t16, t5, 4U);
    if (t18 == 1)
        goto LAB10;

LAB15:    t19 = (t0 + 5348);
    t21 = xsi_mem_cmp(t19, t5, 4U);
    if (t21 == 1)
        goto LAB11;

LAB16:
LAB12:    xsi_set_current_line(53, ng0);
    t1 = (t0 + 5368);
    t3 = (t0 + 3240);
    t5 = (t3 + 56U);
    t6 = *((char **)t5);
    t10 = (t6 + 56U);
    t11 = *((char **)t10);
    memcpy(t11, t1, 4U);
    xsi_driver_first_trans_fast_port(t3);

LAB7:    goto LAB2;

LAB6:;
LAB8:    xsi_set_current_line(49, ng0);
    t22 = (t0 + 5352);
    t24 = (t0 + 3240);
    t25 = (t24 + 56U);
    t26 = *((char **)t25);
    t27 = (t26 + 56U);
    t28 = *((char **)t27);
    memcpy(t28, t22, 4U);
    xsi_driver_first_trans_fast_port(t24);
    goto LAB7;

LAB9:    xsi_set_current_line(50, ng0);
    t1 = (t0 + 5356);
    t3 = (t0 + 3240);
    t5 = (t3 + 56U);
    t6 = *((char **)t5);
    t10 = (t6 + 56U);
    t11 = *((char **)t10);
    memcpy(t11, t1, 4U);
    xsi_driver_first_trans_fast_port(t3);
    goto LAB7;

LAB10:    xsi_set_current_line(51, ng0);
    t1 = (t0 + 5360);
    t3 = (t0 + 3240);
    t5 = (t3 + 56U);
    t6 = *((char **)t5);
    t10 = (t6 + 56U);
    t11 = *((char **)t10);
    memcpy(t11, t1, 4U);
    xsi_driver_first_trans_fast_port(t3);
    goto LAB7;

LAB11:    xsi_set_current_line(52, ng0);
    t1 = (t0 + 5364);
    t3 = (t0 + 3240);
    t5 = (t3 + 56U);
    t6 = *((char **)t5);
    t10 = (t6 + 56U);
    t11 = *((char **)t10);
    memcpy(t11, t1, 4U);
    xsi_driver_first_trans_fast_port(t3);
    goto LAB7;

LAB17:;
LAB19:    xsi_set_current_line(57, ng0);
    t23 = (t0 + 5390);
    t25 = (t0 + 3240);
    t26 = (t25 + 56U);
    t27 = *((char **)t26);
    t28 = (t27 + 56U);
    t30 = *((char **)t28);
    memcpy(t30, t23, 4U);
    xsi_driver_first_trans_fast_port(t25);
    goto LAB18;

LAB20:    xsi_set_current_line(58, ng0);
    t1 = (t0 + 5394);
    t3 = (t0 + 3240);
    t5 = (t3 + 56U);
    t6 = *((char **)t5);
    t10 = (t6 + 56U);
    t11 = *((char **)t10);
    memcpy(t11, t1, 4U);
    xsi_driver_first_trans_fast_port(t3);
    goto LAB18;

LAB21:    xsi_set_current_line(59, ng0);
    t1 = (t0 + 5398);
    t3 = (t0 + 3240);
    t5 = (t3 + 56U);
    t6 = *((char **)t5);
    t10 = (t6 + 56U);
    t11 = *((char **)t10);
    memcpy(t11, t1, 4U);
    xsi_driver_first_trans_fast_port(t3);
    goto LAB18;

LAB22:    xsi_set_current_line(60, ng0);
    t1 = (t0 + 5402);
    t3 = (t0 + 3240);
    t5 = (t3 + 56U);
    t6 = *((char **)t5);
    t10 = (t6 + 56U);
    t11 = *((char **)t10);
    memcpy(t11, t1, 4U);
    xsi_driver_first_trans_fast_port(t3);
    goto LAB18;

LAB23:    xsi_set_current_line(61, ng0);
    t1 = (t0 + 5406);
    t3 = (t0 + 3240);
    t5 = (t3 + 56U);
    t6 = *((char **)t5);
    t10 = (t6 + 56U);
    t11 = *((char **)t10);
    memcpy(t11, t1, 4U);
    xsi_driver_first_trans_fast_port(t3);
    goto LAB18;

LAB24:    xsi_set_current_line(62, ng0);
    t1 = (t0 + 5410);
    t3 = (t0 + 3240);
    t5 = (t3 + 56U);
    t6 = *((char **)t5);
    t10 = (t6 + 56U);
    t11 = *((char **)t10);
    memcpy(t11, t1, 4U);
    xsi_driver_first_trans_fast_port(t3);
    goto LAB18;

LAB32:;
}


extern void work_a_3778041230_3212880686_init()
{
	static char *pe[] = {(void *)work_a_3778041230_3212880686_p_0,(void *)work_a_3778041230_3212880686_p_1};
	xsi_register_didat("work_a_3778041230_3212880686", "isim/tb1_isim_beh.exe.sim/work/a_3778041230_3212880686.didat");
	xsi_register_executes(pe);
}
